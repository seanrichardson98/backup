/// bit manip functions

int bitwise_nor(int x, int y);
int bitwise_xor(int x, int y);
int eval_not_equal(int x, int y);
int get_byte(int x, int n);
int copy_lsbit(int x);
int bit_count(int x);
